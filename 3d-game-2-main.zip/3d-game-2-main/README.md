# connected-earth-museum-v2

Só dar git clone e no repo rodar python -m http.server 8000 . Sem Node e sem React amém
